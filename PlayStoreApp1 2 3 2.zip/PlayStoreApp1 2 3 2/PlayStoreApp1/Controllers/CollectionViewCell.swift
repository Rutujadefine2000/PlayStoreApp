//
//  CollectionViewCell.swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 03/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myimg: UIImageView!
    
    @IBOutlet weak var myimg2: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var idLabel: UILabel!
    
    @IBOutlet weak var popularityLabel: UILabel!
}
