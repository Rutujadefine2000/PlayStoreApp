//
//  MovieCell.swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 03/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import UIKit

class MovieCell: UITableViewCell {

    @IBOutlet weak var mtlbl: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var movieList: [JsonModel] = []
    
    override func awakeFromNib() {
        super.awakeFromNib()
    
        
        collectionView.delegate = self
        collectionView.dataSource = self
       
    }
    
    
    func getDataFromVC(model: [JsonModel]) {
        for data in model {
            self.movieList.append(data)
        }
      
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)


    }

}
extension MovieCell : UICollectionViewDataSource,UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    //return arrData.count
        return movieList.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectioncell", for: indexPath) as? CollectionViewCell
       cell?.titleLabel.text = movieList[indexPath.row].title
      cell?.idLabel.text = movieList[indexPath.row].id
        cell?.popularityLabel.text = movieList[indexPath.row].popularity
     
var baseurl = "https://image.tmdb.org/t/p/w200"
        
   // let joined = baseurl + arrData[indexPath.row].poster_path
//        cell?.myimg.downloaded(from: joined)
//        cell?.myimg2.downloaded(from: joined)
        
        cell?.myimg.layer.cornerRadius = 10.0
        cell?.myimg2.layer.cornerRadius = 10.0
       
       
    
        return cell!
        
    }
    
    
}
