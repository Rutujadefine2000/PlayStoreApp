//
//  myTableViewCell.swift
//  PlayStoreApp1
//
//  Created by Brahmastra on 02/01/23.
//  Copyright © 2023 Brahmastra. All rights reserved.
//

import UIKit

//var arrdata = [JsonModel]()
class myTableViewCell: UITableViewCell {
  // var objData = arrdata
    //var arrdata = [JsonModel]()
    @IBOutlet weak var MyCollectionView: UICollectionView!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
      //  jsonParsing()
        MyCollectionView.delegate = self
        MyCollectionView.dataSource = self
    }

//    func jsonParsing(){
//           let url = URL(string: "https://api.themoviedb.org/3/movie/popular?api_key=60af9fe8e3245c53ad9c4c0af82d56d6&language=en-US&page=1")
//           URLSession.shared.dataTask(with: url!) { (data, response, error) in
//               guard let data = data else { return }
//               do{
//                   let json = try JSON(data: data)
//                   let results = json["results"]
//                   print(results)
//                   for arr in results.arrayValue{
//                    
//                        self.arrdata.append(JsonModel(json: arr))
//                   }
//                DispatchQueue.main.async {
//                    self.MyCollectionView.reloadData()
//                }
//               print(self.arrdata)
//               }catch
//               {
//                   print(error.localizedDescription)
//               }
//           }.resume()
//       }
// 

     
    }


extension myTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrdata.count

    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = MyCollectionView.dequeueReusableCell(withReuseIdentifier: "Collectioncell", for: indexPath) as! MyCollectionView
        cell.myLabel.text = arrdata[indexPath.row].title
//       // cell.myImg.image = arrdata[indexPath.row].poster_path
       cell.myLabel.text = arrdata[indexPath.row].title
         let baseurl = "https://image.tmdb.org/t/p/w200"
        let poster_path = arrdata[indexPath.row].poster_path
         
        let joined = baseurl + poster_path
        print(joined)
        
        return cell

    }


}
